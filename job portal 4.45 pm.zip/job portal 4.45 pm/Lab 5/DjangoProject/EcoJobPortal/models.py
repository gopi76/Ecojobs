from django.contrib.auth.models import AbstractUser
from django.db import models
from django.urls import reverse
from django.core.validators import FileExtensionValidator
from django.utils import timezone
import os


class CustomUser(AbstractUser):
    USER_TYPES = (
        ('applicant', 'Job Applicant'),
        ('recruiter', 'Recruiter'),
    )
    user_type = models.CharField(max_length=20, choices=USER_TYPES, default='applicant')
    phone = models.CharField(max_length=15, blank=True)
    location = models.CharField(max_length=100, blank=True)
    bio = models.TextField(max_length=500, blank=True)
    profile_picture = models.ImageField(upload_to='profiles/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.username} ({self.get_user_type_display()})"


class Job(models.Model):
    SECTORS = (
        ('renewable', 'Renewable Energy'),
        ('conservation', 'Environmental Conservation'),
        ('sustainability', 'Sustainability Consulting'),
        ('green_tech', 'Green Technology'),
        ('waste_mgmt', 'Waste Management'),
        ('climate', 'Climate Science'),
        ('organic_farming', 'Organic Farming'),
        ('eco_transport', 'Eco Transportation'),
    )

    JOB_TYPES = (
        ('full_time', 'Full Time'),
        ('part_time', 'Part Time'),
        ('contract', 'Contract'),
        ('remote', 'Remote'),
        ('hybrid', 'Hybrid'),
    )

    title = models.CharField(max_length=200)
    company = models.CharField(max_length=150)
    description = models.TextField()
    requirements = models.TextField()
    sector = models.CharField(max_length=20, choices=SECTORS)
    job_type = models.CharField(max_length=20, choices=JOB_TYPES)
    salary_min = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    salary_max = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    location = models.CharField(max_length=100)
    is_remote = models.BooleanField(default=False)
    posted_by = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='posted_jobs')
    posted_date = models.DateTimeField(auto_now_add=True)
    deadline = models.DateTimeField()
    is_active = models.BooleanField(default=True)
    tags = models.CharField(max_length=200, help_text="Comma-separated tags (e.g., solar, sustainability)", blank=True)

    class Meta:
        ordering = ['-posted_date']

    def __str__(self):
        return f"{self.title} at {self.company}"

    def get_absolute_url(self):
        return reverse('job_detail', kwargs={'pk': self.pk})

    def get_tags_list(self):

        if self.tags:
            return [tag.strip() for tag in self.tags.split(',') if tag.strip()]
        return []

    def get_tags_display(self):

        tags = self.get_tags_list()
        if tags:
            return ', '.join(f"#{tag}" for tag in tags)
        return ""


    def get_status(self):

        if not self.is_active:
            return 'deleted'
        elif self.deadline < timezone.now():
            return 'expired'
        else:
            return 'active'

    def get_status_display(self):

        status = self.get_status()
        status_map = {
            'active': 'Active',
            'expired': 'Expired',
            'deleted': 'Deleted'
        }
        return status_map.get(status, 'Unknown')

    def get_status_color(self):

        status = self.get_status()
        color_map = {
            'active': 'success',
            'expired': 'warning',
            'deleted': 'secondary'
        }
        return color_map.get(status, 'secondary')

    def is_expired(self):

        return self.deadline < timezone.now()

    def days_until_deadline(self):

        delta = self.deadline - timezone.now()
        return delta.days

    def can_apply(self):

        return self.is_active


class Application(models.Model):
    STATUS_CHOICES = (
        ('pending', 'Pending Review'),
        ('reviewed', 'Under Review'),
        ('interview', 'Interview Scheduled'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
    )


    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='applications')
    applicant = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='applications')
    applied_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    recruiter_notes = models.TextField(blank=True)


    cover_letter = models.TextField(max_length=2000)
    resume = models.FileField(
        upload_to='resumes/',
        validators=[FileExtensionValidator(allowed_extensions=['pdf', 'doc', 'docx'])]
    )


    full_name = models.CharField(max_length=100, default='')
    email = models.EmailField(default='')
    phone = models.CharField(max_length=20, default='')
    address = models.CharField(max_length=200, default='')


    WORK_AUTHORIZATION_CHOICES = [
        ('citizen', 'Canadian Citizen'),
        ('permanent_resident', 'Permanent Resident'),
        ('work_permit', 'Work Permit Holder'),
        ('student_permit', 'Student Permit'),
        ('need_sponsorship', 'Need Work Sponsorship'),
    ]
    work_authorization = models.CharField(max_length=20, choices=WORK_AUTHORIZATION_CHOICES, default='citizen')


    years_experience = models.IntegerField(default=0)


    linkedin_url = models.URLField(blank=True)
    github_url = models.URLField(blank=True)
    portfolio_url = models.URLField(blank=True)


    available_start_date = models.DateField(null=True, blank=True)
    expected_salary = models.IntegerField(null=True, blank=True)

    REMOTE_WORK_CHOICES = [
        ('onsite', 'On-site only'),
        ('remote', 'Remote only'),
        ('hybrid', 'Hybrid (flexible)'),
        ('either', 'Either on-site or remote')
    ]
    remote_work_preference = models.CharField(max_length=10, choices=REMOTE_WORK_CHOICES, default='either')

    class Meta:
        unique_together = ['job', 'applicant']
        ordering = ['-applied_date']

    def __str__(self):
        return f"{self.full_name or self.applicant.username} - {self.job.title}"

    def get_work_authorization_display_color(self):

        colors = {
            'citizen': 'success',
            'permanent_resident': 'success',
            'work_permit': 'info',
            'student_permit': 'warning',
            'need_sponsorship': 'danger'
        }
        return colors.get(self.work_authorization, 'secondary')


class UserHistory(models.Model):
    ACTION_CHOICES = (
        ('viewed', 'Viewed Job'),
        ('applied', 'Applied to Job'),
        ('saved', 'Saved Job'),
        ('searched', 'Searched'),
    )

    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='history')
    job = models.ForeignKey(Job, on_delete=models.CASCADE, null=True, blank=True)
    action = models.CharField(max_length=20, choices=ACTION_CHOICES)
    search_query = models.CharField(max_length=200, blank=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    ip_address = models.GenericIPAddressField(null=True, blank=True)

    class Meta:
        ordering = ['-timestamp']
        verbose_name_plural = "User Histories"

    def __str__(self):
        if self.job:
            return f"{self.user.username} {self.action} {self.job.title}"
        return f"{self.user.username} {self.action}"


class SavedJob(models.Model):
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='saved_jobs')
    job = models.ForeignKey(Job, on_delete=models.CASCADE, related_name='saved_by')
    saved_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ['user', 'job']

    def __str__(self):
        return f"{self.user.username} saved {self.job.title}"