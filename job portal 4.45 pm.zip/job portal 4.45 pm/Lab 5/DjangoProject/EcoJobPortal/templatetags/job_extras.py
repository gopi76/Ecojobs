# Create this file: EcoJobPortal/templatetags/job_extras.py

from django import template

register = template.Library()

@register.filter
def split_tags(value, arg=','):
    """Split a string by the given separator"""
    if not value:
        return []
    return [tag.strip() for tag in value.split(arg) if tag.strip()]