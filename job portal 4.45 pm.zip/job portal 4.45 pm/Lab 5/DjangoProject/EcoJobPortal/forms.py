
from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import authenticate
from .models import CustomUser, Job, Application
from django.core.exceptions import ValidationError


class CustomUserCreationForm(UserCreationForm):
    email = forms.EmailField(required=True)
    user_type = forms.ChoiceField(choices=CustomUser.USER_TYPES, required=True)
    phone = forms.CharField(max_length=15, required=False)
    location = forms.CharField(max_length=100, required=False)

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'password1', 'password2', 'user_type', 'phone', 'location')

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.user_type = self.cleaned_data['user_type']
        user.phone = self.cleaned_data['phone']
        user.location = self.cleaned_data['location']
        if commit:
            user.save()
        return user


class JobPostingForm(forms.ModelForm):
    deadline = forms.DateTimeField(
        widget=forms.DateTimeInput(attrs={'type': 'datetime-local'}),
        help_text="Application deadline"
    )

    class Meta:
        model = Job
        fields = [
            'title', 'company', 'description', 'requirements',
            'sector', 'job_type', 'salary_min', 'salary_max',
            'location', 'is_remote', 'deadline', 'tags'
        ]
        widgets = {
            'description': forms.Textarea(attrs={'rows': 5}),
            'requirements': forms.Textarea(attrs={'rows': 4}),
            'tags': forms.TextInput(attrs={'placeholder': 'e.g., solar, python, remote'})
        }


class JobApplicationForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = [
            'cover_letter', 'resume', 'full_name', 'email', 'phone', 'address',
            'work_authorization', 'years_experience', 'linkedin_url', 'github_url',
            'portfolio_url', 'available_start_date', 'expected_salary', 'remote_work_preference'
        ]

        widgets = {
            'cover_letter': forms.Textarea(attrs={
                'rows': 6,
                'class': 'form-control',
                'placeholder': 'Tell us why you\'re interested in this green career opportunity and what makes you a great fit...',
            }),
            'resume': forms.FileInput(attrs={
                'accept': '.pdf,.doc,.docx',
                'class': 'form-control'
            }),
            'full_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Your full name'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'your.email@example.com'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': '+1 (555) 123-4567'
            }),
            'address': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Your address'
            }),
            'work_authorization': forms.Select(attrs={
                'class': 'form-select'
            }),
            'years_experience': forms.NumberInput(attrs={
                'class': 'form-control',
                'min': 0,
                'max': 50
            }),
            'linkedin_url': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://linkedin.com/in/yourprofile'
            }),
            'github_url': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://github.com/yourusername'
            }),
            'portfolio_url': forms.URLInput(attrs={
                'class': 'form-control',
                'placeholder': 'https://yourportfolio.com'
            }),
            'available_start_date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'expected_salary': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': '50000'
            }),
            'remote_work_preference': forms.Select(attrs={
                'class': 'form-select'
            }),
        }

    def __init__(self, user=None, *args, **kwargs):
        super().__init__(*args, **kwargs)


        if user and not self.instance.pk:
            self.fields['full_name'].initial = user.get_full_name() or user.username
            self.fields['email'].initial = user.email
            if hasattr(user, 'phone') and user.phone:
                self.fields['phone'].initial = user.phone
            if hasattr(user, 'location') and user.location:
                self.fields['address'].initial = user.location


        self.fields['cover_letter'].required = True
        self.fields['resume'].required = True
        self.fields['full_name'].required = True
        self.fields['email'].required = True
        self.fields['phone'].required = True
        self.fields['address'].required = True
        self.fields['work_authorization'].required = True
        self.fields['years_experience'].required = True
        self.fields['available_start_date'].required = True
        self.fields['remote_work_preference'].required = True

    def clean_resume(self):
        resume = self.cleaned_data.get('resume')
        if resume:
            # Checking file size
            if resume.size > 5 * 1024 * 1024:
                raise ValidationError('File size cannot exceed 5MB.')
        return resume


class JobSearchForm(forms.Form):
    search = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Search jobs, companies, or skills...',
            'class': 'form-control'
        })
    )
    sector = forms.ChoiceField(
        choices=[('', 'All Sectors')] + list(Job.SECTORS),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    job_type = forms.ChoiceField(
        choices=[('', 'All Types')] + list(Job.JOB_TYPES),
        required=False,
        widget=forms.Select(attrs={'class': 'form-control'})
    )
    location = forms.CharField(
        max_length=100,
        required=False,
        widget=forms.TextInput(attrs={
            'placeholder': 'Location...',
            'class': 'form-control'
        })
    )
    remote_only = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )


class ProfileUpdateForm(forms.ModelForm):


    class Meta:
        model = CustomUser
        fields = [
            'first_name', 'last_name', 'email', 'phone',
            'location', 'bio', 'profile_picture'
        ]
        widgets = {
            'first_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'First Name'
            }),
            'last_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Last Name'
            }),
            'email': forms.EmailInput(attrs={
                'class': 'form-control',
                'placeholder': 'Email Address'
            }),
            'phone': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Phone Number'
            }),
            'location': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'City, Province/State'
            }),
            'bio': forms.Textarea(attrs={
                'class': 'form-control',
                'rows': 4,
                'placeholder': 'Tell us about yourself and your green career interests...'
            }),
            'profile_picture': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*'
            })
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        username = self.instance.username

        # Checking if email is already taken by another user
        if CustomUser.objects.exclude(username=username).filter(email=email).exists():
            raise forms.ValidationError('This email address is already in use.')

        return email


class ChangePasswordForm(forms.Form):


    current_password = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Current Password'
        })
    )
    new_password1 = forms.CharField(
        label='New Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'New Password'
        })
    )
    new_password2 = forms.CharField(
        label='Confirm New Password',
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Confirm New Password'
        })
    )

    def __init__(self, user, *args, **kwargs):
        self.user = user
        super().__init__(*args, **kwargs)

    def clean_current_password(self):
        current_password = self.cleaned_data.get('current_password')
        if not self.user.check_password(current_password):
            raise forms.ValidationError('Current password is incorrect.')
        return current_password

    def clean(self):
        cleaned_data = super().clean()
        new_password1 = cleaned_data.get('new_password1')
        new_password2 = cleaned_data.get('new_password2')

        if new_password1 and new_password2:
            if new_password1 != new_password2:
                raise forms.ValidationError('New passwords do not match.')

        return cleaned_data


class ForgotPasswordForm(forms.Form):
    identifier = forms.CharField(
        max_length=254,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter your username or email',
            'required': True
        }),
        label='Username or Email'
    )

    def clean_identifier(self):
        identifier = self.cleaned_data.get('identifier', '').strip()
        if not identifier:
            raise forms.ValidationError('This field is required.')
        return identifier


class NewPasswordForm(forms.Form):
    password1 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter new password',
            'required': True
        }),
        label='New Password',
        min_length=8
    )

    password2 = forms.CharField(
        widget=forms.PasswordInput(attrs={
            'class': 'form-control',
            'placeholder': 'Confirm new password',
            'required': True
        }),
        label='Confirm Password'
    )

    def clean(self):
        cleaned_data = super().clean()
        password1 = cleaned_data.get('password1')
        password2 = cleaned_data.get('password2')

        if password1 and password2:
            if password1 != password2:
                raise forms.ValidationError('Passwords do not match.')

        return cleaned_data