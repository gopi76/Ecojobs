
from django.urls import path
from django.contrib.auth import views as auth_views
from . import views

urlpatterns = [
    # Home
    path('', views.home, name='home'),

    # Authentication
    path('register/', views.register, name='register'),
    path('login/', auth_views.LoginView.as_view(), name='login'),
    path('logout/', views.custom_logout, name='logout'),

    # FORGOT PASSWORD
    path('forgot-password/', views.forgot_password_view, name='forgot_password'),
    path('reset-password/', views.password_reset_new_view, name='password_reset_new'),
    path('check-user-exists/', views.check_user_exists, name='check_user_exists'),

    # EMAIL-BASED PASSWORD RESET
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    path('password_reset/done/', auth_views.PasswordResetDoneView.as_view(), name='password_reset_done'),
    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(), name='password_reset_complete'),

    # Profile Management
    path('profile/', views.profile_view, name='profile_view'),
    path('profile/edit/', views.profile_edit, name='profile_edit'),
    path('profile/change-password/', views.change_password, name='change_password'),

    # Jobs
    path('jobs/', views.JobListView.as_view(), name='job_list'),
    path('jobs/<int:pk>/', views.JobDetailView.as_view(), name='job_detail'),
    path('jobs/<int:job_id>/apply/', views.apply_job, name='apply_job'),
    path('jobs/post/', views.post_job, name='post_job'),

    path('jobs/<int:job_id>/edit/', views.edit_job, name='edit_job'),
    path('jobs/<int:job_id>/delete/', views.delete_job, name='delete_job'),

    # Job Applications Management
    path('jobs/<int:job_id>/applications/', views.manage_job_applications, name='manage_job_applications'),
    path('applications/<int:application_id>/', views.view_application_detail, name='view_application_detail'),
    path('applications/<int:application_id>/download-resume/', views.download_resume, name='download_resume'),

    # Dashboard
    path('dashboard/', views.user_dashboard, name='dashboard'),
    path('saved-jobs/', views.saved_jobs, name='saved_jobs'),
    path('jobs/<int:job_id>/toggle-save/', views.toggle_save_job, name='toggle_save_job'),
    path('profile/change-password/', views.change_password, name='change_password'),
    # Static Pages
    path('about/', views.about_us, name='about_us'),
    path('contact/', views.contact, name='contact'),
    path('privacy/', views.privacy_policy, name='privacy_policy'),
    path('terms/', views.terms_of_service, name='terms_of_service'),

    # Resume Search
    path('search-resumes/', views.search_resumes, name='search_resumes'),

]