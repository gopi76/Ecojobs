# EcoJobPortal/admin.py
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import CustomUser, Job, Application, UserHistory, SavedJob

@admin.register(CustomUser)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'user_type', 'date_joined']
    list_filter = ['user_type', 'date_joined']
    fieldsets = UserAdmin.fieldsets + (
        ('Additional Info', {'fields': ('user_type', 'phone', 'location', 'bio', 'profile_picture')}),
    )

@admin.register(Job)
class JobAdmin(admin.ModelAdmin):
    list_display = ['title', 'company', 'sector', 'job_type', 'location', 'posted_by', 'posted_date', 'is_active']
    list_filter = ['sector', 'job_type', 'is_active', 'posted_date']
    search_fields = ['title', 'company', 'description']
    readonly_fields = ['posted_date']

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ['applicant', 'job', 'status', 'applied_date']
    list_filter = ['status', 'applied_date']
    search_fields = ['applicant__username', 'job__title']

@admin.register(UserHistory)
class UserHistoryAdmin(admin.ModelAdmin):
    list_display = ['user', 'action', 'job', 'timestamp']
    list_filter = ['action', 'timestamp']
    readonly_fields = ['timestamp']

admin.site.register(SavedJob)