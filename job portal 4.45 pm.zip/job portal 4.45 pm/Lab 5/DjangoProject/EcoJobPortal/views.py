from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, logout, update_session_auth_hash
from .models import Job, Application, UserHistory, CustomUser, SavedJob
from django.contrib.auth.decorators import login_required
from django.contrib.auth.mixins import LoginRequiredMixin
from django.views.generic import ListView, DetailView, CreateView
from django.contrib import messages
from django.db.models import Q
from django.core.paginator import Paginator
from django.http import Http404, HttpResponse, JsonResponse
from django.core.mail import send_mail
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
from django.utils import timezone
import json

from .models import Job, Application, UserHistory, CustomUser
from .forms import (
    CustomUserCreationForm, JobPostingForm, JobApplicationForm,
    JobSearchForm, ProfileUpdateForm, ChangePasswordForm
)


def home(request):

    recent_jobs = Job.objects.filter(is_active=True)[:6]
    context = {
        'recent_jobs': recent_jobs,
        'total_jobs': Job.objects.filter(is_active=True).count(),
        'total_companies': Job.objects.filter(is_active=True).values('company').distinct().count(),
    }
    return render(request, 'home.html', context)


def register(request):
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f'Welcome to EcoJobs, {user.username}!')
            return redirect('home')
    else:
        form = CustomUserCreationForm()
    return render(request, 'registration/register.html', {'form': form})


def custom_logout(request):

    logout(request)
    messages.success(request, 'You have been successfully logged out.')
    return redirect('home')


def forgot_password_view(request):

    if request.method == 'POST':
        identifier = request.POST.get('identifier', '').strip()

        if not identifier:
            messages.error(request, 'Please enter your username or email.')
            return render(request, 'registration/forgot_password.html')


        user = None
        try:

            if '@' in identifier:
                user = CustomUser.objects.get(email=identifier)
            else:

                user = CustomUser.objects.get(username=identifier)
        except CustomUser.DoesNotExist:

            messages.error(request, 'No account found with that username or email. Please sign up first.')
            return render(request, 'registration/forgot_password.html')


        request.session['reset_user_id'] = user.id
        messages.success(request, f'Account found for {user.username}. Please set your new password.')
        return redirect('password_reset_new')

    return render(request, 'registration/forgot_password.html')


def password_reset_new_view(request):

    user_id = request.session.get('reset_user_id')
    if not user_id:
        messages.error(request, 'Invalid password reset session. Please try again.')
        return redirect('forgot_password')

    try:
        user = CustomUser.objects.get(id=user_id)
    except CustomUser.DoesNotExist:
        messages.error(request, 'User not found. Please try again.')
        return redirect('forgot_password')

    if request.method == 'POST':
        password1 = request.POST.get('password1', '')
        password2 = request.POST.get('password2', '')

        # Validate passwords
        if not password1 or not password2:
            messages.error(request, 'Both password fields are required.')
            return render(request, 'registration/password_reset_new.html', {'user': user})

        if password1 != password2:
            messages.error(request, 'Passwords do not match.')
            return render(request, 'registration/password_reset_new.html', {'user': user})

        if len(password1) < 8:
            messages.error(request, 'Password must be at least 8 characters long.')
            return render(request, 'registration/password_reset_new.html', {'user': user})

        # Update password
        user.set_password(password1)
        user.save()

        # Clear session
        del request.session['reset_user_id']

        messages.success(request, 'Password updated successfully! You can now login with your new password.')
        return redirect('login')

    return render(request, 'registration/password_reset_new.html', {'user': user})


@csrf_exempt
def check_user_exists(request):

    if request.method == 'POST':
        data = json.loads(request.body)
        identifier = data.get('identifier', '').strip()

        if not identifier:
            return JsonResponse({'exists': False, 'message': 'Please enter username or email'})

        # Checking if user exists
        user_exists = False
        try:
            if '@' in identifier:
                CustomUser.objects.get(email=identifier)
            else:
                CustomUser.objects.get(username=identifier)
            user_exists = True
        except CustomUser.DoesNotExist:
            pass

        return JsonResponse({
            'exists': user_exists,
            'message': 'User found' if user_exists else 'No account found with that username or email'
        })

    return JsonResponse({'exists': False, 'message': 'Invalid request'})



@login_required
def profile_view(request):

    user = request.user
    context = {
        'user': user,
    }
    return render(request, 'profile/profile.html', context)


@login_required
def profile_edit(request):

    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Your profile has been updated successfully!')
            return redirect('profile_view')
    else:
        form = ProfileUpdateForm(instance=request.user)

    return render(request, 'profile/profile_edit.html', {'form': form})


@login_required
def change_password(request):

    if request.method == 'POST':
        form = ChangePasswordForm(request.user, request.POST)
        if form.is_valid():
            new_password = form.cleaned_data['new_password1']
            request.user.set_password(new_password)
            request.user.save()


            update_session_auth_hash(request, request.user)

            messages.success(request, 'Your password has been changed successfully!')
            return redirect('profile_view')
    else:
        form = ChangePasswordForm(request.user)

    return render(request, 'profile/change_password.html', {'form': form})



class JobListView(ListView):
    model = Job
    template_name = 'jobs/job_list.html'
    context_object_name = 'jobs'
    paginate_by = 10

    def get_queryset(self):
        queryset = Job.objects.filter(is_active=True).order_by('-posted_date')

        form = JobSearchForm(self.request.GET)
        if form.is_valid():
            search = form.cleaned_data.get('search')
            sector = form.cleaned_data.get('sector')
            job_type = form.cleaned_data.get('job_type')
            location = form.cleaned_data.get('location')
            remote_only = form.cleaned_data.get('remote_only')

            if search:
                queryset = queryset.filter(
                    Q(title__icontains=search) |
                    Q(company__icontains=search) |
                    Q(tags__icontains=search) |
                    Q(description__icontains=search)
                )

            if sector:
                queryset = queryset.filter(sector=sector)

            if job_type:
                queryset = queryset.filter(job_type=job_type)

            if location:
                queryset = queryset.filter(location__icontains=location)

            if remote_only:
                queryset = queryset.filter(is_remote=True)

        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search_form'] = JobSearchForm(self.request.GET)

        # Convert tags into a list for each job
        for job in context['jobs']:
            if job.tags:
                job.tags_list = [tag.strip() for tag in job.tags.split(',')]
            else:
                job.tags_list = []

        return context


class JobDetailView(DetailView):
    model = Job
    template_name = 'jobs/job_detail.html'
    context_object_name = 'job'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        # Track job view
        if self.request.user.is_authenticated:
            UserHistory.objects.create(
                user=self.request.user,
                job=self.object,
                action='viewed'
            )

        # Check if user already applied
        if self.request.user.is_authenticated:
            context['already_applied'] = Application.objects.filter(
                job=self.object,
                applicant=self.request.user
            ).exists()

        return context


@login_required
def post_job(request):

    if request.user.user_type != 'recruiter':
        messages.error(request, 'Only recruiters can post jobs.')
        return redirect('home')

    if request.method == 'POST':
        form = JobPostingForm(request.POST)
        if form.is_valid():
            job = form.save(commit=False)
            job.posted_by = request.user
            job.save()

            messages.success(request, f'Job "{job.title}" has been posted successfully!')
            return redirect('job_detail', pk=job.pk)
    else:
        form = JobPostingForm()

    return render(request, 'jobs/post_job.html', {'form': form})


@login_required
def edit_job(request, job_id):

    job = get_object_or_404(Job, id=job_id, posted_by=request.user)


    if request.user.user_type != 'recruiter':
        messages.error(request, 'Only recruiters can edit jobs.')
        return redirect('home')

    if request.method == 'POST':
        form = JobPostingForm(request.POST, instance=job)
        if form.is_valid():
            updated_job = form.save()
            messages.success(request, f'Job "{updated_job.title}" has been updated successfully!')
            return redirect('job_detail', pk=updated_job.pk)
    else:
        form = JobPostingForm(instance=job)

    context = {
        'form': form,
        'job': job,
        'is_edit': True,
    }
    return render(request, 'jobs/edit_job.html', context)


@login_required
def delete_job(request, job_id):

    job = get_object_or_404(Job, id=job_id, posted_by=request.user)


    if request.user.user_type != 'recruiter':
        messages.error(request, 'Only recruiters can delete jobs.')
        return redirect('home')

    if request.method == 'POST':

        job.is_active = False
        job.save()

        messages.success(request, f'Job "{job.title}" has been deleted successfully!')
        return redirect('dashboard')


    context = {
        'job': job,
        'applications_count': Application.objects.filter(job=job).count()
    }
    return render(request, 'jobs/delete_job_confirm.html', context)


@login_required
def apply_job(request, job_id):

    job = get_object_or_404(Job, id=job_id, is_active=True)

    # Check if user is applicant
    if request.user.user_type != 'applicant':
        messages.error(request, 'Only job seekers can apply for jobs.')
        return redirect('job_detail', pk=job_id)

    # Check if already applied
    if Application.objects.filter(job=job, applicant=request.user).exists():
        messages.warning(request, 'You have already applied for this job.')
        return redirect('job_detail', pk=job_id)

    if request.method == 'POST':

        form = JobApplicationForm(user=request.user, data=request.POST, files=request.FILES)
        if form.is_valid():
            application = form.save(commit=False)
            application.job = job
            application.applicant = request.user
            application.save()

            # Track application in history
            UserHistory.objects.create(
                user=request.user,
                job=job,
                action='applied'
            )

            messages.success(request, f'Application submitted successfully for {job.title}!')
            return redirect('job_detail', pk=job_id)
    else:

        form = JobApplicationForm(user=request.user)

    context = {
        'form': form,
        'job': job,
    }
    return render(request, 'jobs/apply_job.html', context)


@login_required
def manage_job_applications(request, job_id):

    job = get_object_or_404(Job, id=job_id, posted_by=request.user)

    applications = Application.objects.filter(job=job).order_by('-applied_date')


    paginator = Paginator(applications, 10)
    page_number = request.GET.get('page')
    applications = paginator.get_page(page_number)


    stats = {
        'total': Application.objects.filter(job=job).count(),
        'pending': Application.objects.filter(job=job, status='pending').count(),
        'reviewed': Application.objects.filter(job=job, status='reviewed').count(),
        'interview': Application.objects.filter(job=job, status='interview').count(),
        'accepted': Application.objects.filter(job=job, status='accepted').count(),
        'rejected': Application.objects.filter(job=job, status='rejected').count(),
    }

    context = {
        'job': job,
        'applications': applications,
        'stats': stats,
    }

    return render(request, 'jobs/manage_applications.html', context)


@login_required
def view_application_detail(request, application_id):

    application = get_object_or_404(Application, id=application_id)

    # Check if user owns the job posting
    if application.job.posted_by != request.user:
        messages.error(request, 'You can only view applications for your own job postings.')
        return redirect('dashboard')

    if request.method == 'POST':
        # Update application status
        if 'update_status' in request.POST:
            new_status = request.POST.get('status')
            if new_status in dict(Application.STATUS_CHOICES):
                application.status = new_status
                application.save()
                messages.success(request, f'Application status updated to {application.get_status_display()}')

        # Update recruiter notes
        elif 'update_notes' in request.POST:
            recruiter_notes = request.POST.get('recruiter_notes', '')
            application.recruiter_notes = recruiter_notes
            application.save()
            messages.success(request, 'Notes saved successfully!')

        return redirect('view_application_detail', application_id=application.id)

    return render(request, 'jobs/application_detail.html', {'application': application})


@login_required
def download_resume(request, application_id):

    application = get_object_or_404(Application, id=application_id)

    # Check if user owns the job posting
    if application.job.posted_by != request.user:
        raise Http404("File not found")

    if application.resume:
        response = HttpResponse(application.resume.read(), content_type='application/octet-stream')
        response[
            'Content-Disposition'] = f'attachment; filename="{application.full_name}_Resume.{application.resume.name.split(".")[-1]}"'
        return response
    else:
        messages.error(request, 'Resume not found.')
        return redirect('view_application_detail', application_id=application.id)


@login_required
def user_dashboard(request):
    if request.user.user_type == 'recruiter':

        posted_jobs = Job.objects.filter(posted_by=request.user).order_by('-posted_date')
        total_applications = Application.objects.filter(job__posted_by=request.user)


        active_jobs = posted_jobs.filter(is_active=True)
        inactive_jobs = posted_jobs.filter(is_active=False)


        now = timezone.now()
        expired_jobs_count = active_jobs.filter(deadline__lt=now).count()

        # Job statistics
        job_stats = {
            'total': posted_jobs.count(),
            'active': active_jobs.filter(deadline__gte=now).count(),
            'expired': expired_jobs_count,
            'deleted': inactive_jobs.count(),
        }

        context = {
            'posted_jobs': posted_jobs[:10],
            'job_stats': job_stats,
            'total_applications': total_applications.count(),
            'recent_applications': total_applications.order_by('-applied_date')[:5],
            'pending_applications': total_applications.filter(status='pending').count(),
            'now': now,
        }
        template = 'dashboard/recruiter_dashboard.html'
    else:

        applications = Application.objects.filter(applicant=request.user)
        recent_history = UserHistory.objects.filter(user=request.user)[:10]

        context = {
            'applications': applications[:5],
            'total_applications': applications.count(),
            'recent_history': recent_history,
        }
        template = 'dashboard/applicant_dashboard.html'

    return render(request, template, context)


@login_required
def saved_jobs(request):

    if request.user.user_type != 'applicant':
        messages.error(request, 'Only job seekers can access saved jobs.')
        return redirect('dashboard')

    saved_jobs = SavedJob.objects.filter(user=request.user).order_by('-saved_date')


    paginator = Paginator(saved_jobs, 10)
    page_number = request.GET.get('page')
    saved_jobs = paginator.get_page(page_number)

    context = {
        'saved_jobs': saved_jobs,
    }
    return render(request, 'jobs/saved_jobs.html', context)


@login_required
def toggle_save_job(request, job_id):

    job = get_object_or_404(Job, id=job_id, is_active=True)

    # Only applicants can save jobs
    if request.user.user_type != 'applicant':
        messages.error(request, 'Only job seekers can save jobs.')
        return redirect('job_detail', pk=job_id)


    saved_job = SavedJob.objects.filter(user=request.user, job=job).first()

    if saved_job:

        saved_job.delete()
        messages.success(request, f'Job "{job.title}" removed from saved jobs.')
    else:

        SavedJob.objects.create(user=request.user, job=job)
        messages.success(request, f'Job "{job.title}" saved successfully!')


        UserHistory.objects.create(
            user=request.user,
            job=job,
            action='saved'
        )


    return redirect('job_detail', pk=job_id)



def about_us(request):

    return render(request, 'company/about_us.html')


def contact(request):

    return render(request, 'company/contact.html')


def privacy_policy(request):

    return render(request, 'company/privacy_policy.html')


def terms_of_service(request):

    return render(request, 'company/terms_of_service.html')



@login_required
def search_resumes(request):

    if request.user.user_type != 'recruiter':
        messages.error(request,
                       'You must be logged in as a recruiter to search resumes. Please login with a recruiter account.')
        return redirect('login')


    applications = Application.objects.filter(
        job__posted_by=request.user
    ).order_by('-applied_date')

    # search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        applications = applications.filter(
            Q(full_name__icontains=search_query) |
            Q(job__title__icontains=search_query) |
            Q(job__company__icontains=search_query) |
            Q(applicant__username__icontains=search_query)
        )


    paginator = Paginator(applications, 15)
    page_number = request.GET.get('page')
    applications = paginator.get_page(page_number)


    stats = {
        'total_applications': Application.objects.filter(job__posted_by=request.user).count(),
        'pending': Application.objects.filter(job__posted_by=request.user, status='pending').count(),
        'reviewed': Application.objects.filter(job__posted_by=request.user, status='reviewed').count(),
        'interview': Application.objects.filter(job__posted_by=request.user, status='interview').count(),
        'accepted': Application.objects.filter(job__posted_by=request.user, status='accepted').count(),
        'rejected': Application.objects.filter(job__posted_by=request.user, status='rejected').count(),
    }

    context = {
        'applications': applications,
        'search_query': search_query,
        'stats': stats,
    }

    return render(request, 'jobs/search_resumes.html', context)
